# Hint for calculates_results_stats function
# Count: n_images, n_dogs_img, n_notdogs_img
# Count: n_correct_dogs, n_correct_notdogs, n_correct_breed
# Calculate percentages: pct_correct_dogs, pct_correct_notdogs, pct_correct_breed
