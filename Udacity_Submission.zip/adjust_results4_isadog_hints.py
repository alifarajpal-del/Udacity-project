# Hint for adjust_results4_isadog function
# Read dognames from dogfile
# Check if pet label is in dog names list
# Check if classifier label contains any dog breed name
# Add is_dog flags to results dictionary
