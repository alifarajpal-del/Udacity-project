# Hint for get_pet_labels function
# Use os.listdir() to get filenames
# Process each filename: lower(), split on _ and remove digits
# Store in dictionary: {filename: [label]}
