# Hint for print_results function
# Print model architecture
# Print statistics from results_stats_dic
# Optionally print misclassified dogs and breeds
