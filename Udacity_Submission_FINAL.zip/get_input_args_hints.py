# Hint for get_input_args function
# Use argparse.ArgumentParser() to create parser
# Add arguments: --dir, --arch, --dogfile  
# Use parser.parse_args() to return Namespace object
