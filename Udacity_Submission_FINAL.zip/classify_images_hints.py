# Hint for classify_images function
# Call classifier(image_path, model_name) for each image
# Compare pet label with classifier label
# Store results: [pet_label, classifier_label, match]
